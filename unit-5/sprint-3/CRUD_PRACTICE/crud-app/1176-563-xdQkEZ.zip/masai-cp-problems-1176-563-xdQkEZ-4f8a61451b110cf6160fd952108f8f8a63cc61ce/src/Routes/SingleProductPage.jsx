
function SingleProductPage(){

    return (
        <div data-testid="products-container">   
            <div>
                <h3 data-testid="product-brand"></h3>
            </div>
            <div >
            <img data-testid="product-image"/>
            </div>
            <div data-testid="product-category">
            </div>
           
            <div data-testid="product-details">
            </div>
            <div data-testid="product-price">
            </div>

            </div>
    )
}
export default SingleProductPage